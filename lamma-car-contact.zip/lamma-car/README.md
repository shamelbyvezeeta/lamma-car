# Lamma Car

**Find it. Sell it. Easy.** — a Lamma Mobility service.

Lamma Car is a **QR contact service**. A QR sticker inside a car's rear window opens a simple page that shows only:

1. the registered person's **display name** (e.g. "Ahmed M."),
2. their **Egyptian mobile number**,
3. a **Call** button,
4. a **WhatsApp** button (opens a chat with the same number).

No vehicle information, no accounts, no payments, no chat system, no server, no database. One QR code = one person = one phone number. Arabic is the default language; English is one tap away.

## How it works

```
records/7KQ2M9XH4D.json   (PRIVATE repository)
        │  GitHub Actions: check → build → publish
        ▼
https://<site>/q/7KQ2M9XH4D   (PUBLIC GitHub Pages page = the address inside the QR)
```

- The source records live in a **private** GitHub repository (GitHub Pro). Only the generated pages are published.
- Each person's page shows nothing but their approved display name and number — and only while the record is **active**.
- Everything is managed from **github.com → Actions**, using forms:

| I want to… | Use | Guide |
|---|---|---|
| Put the site online (once) | Private repository + GitHub Pages | [docs/SETUP_GITHUB_PAGES.md](docs/SETUP_GITHUB_PAGES.md) |
| Add a person and get their sticker | **Actions → Add record** | [docs/MANAGING_RECORDS.md](docs/MANAGING_RECORDS.md) |
| Change name/number, hide, reactivate, retire | **Actions → Manage record** | [docs/MANAGING_RECORDS.md](docs/MANAGING_RECORDS.md) |
| Print or reprint a sticker | **Actions → Make sticker files** | [docs/QR_AND_STICKERS.md](docs/QR_AND_STICKERS.md) |
| Handle consent withdrawal / deletion | Retire + history clean-up | [docs/PRIVACY_AND_PUBLIC_DATA.md](docs/PRIVACY_AND_PUBLIC_DATA.md) |

> 🔒 **Keep the repository private.** The website is public: anyone who scans a sticker (or has its address) can see that person's display name and number. Signed consent forms are kept **outside GitHub**.

## Repository contents

```
records/            one JSON file per person/QR (private source data)
site.json           site settings (address, optional Lamma support contact)
.github/workflows/  Add record · Manage record · Publish website · Make sticker files · Check records
tools/              the small programs those workflows run (checks, build, stickers)
web/                design: CSS, fonts, Lamma Car logo files, 404 helper script
sticker/            master sticker design files (90 × 130 mm)
docs/               guides, privacy, sticker print specification, brand guidelines
tests/              automated tests (developers)
```

## For developers (optional)

```bash
npm ci
npm run validate                                          # check records/ and site.json
PAGES_BASE_URL=https://example.github.io/car npm run build && npm run serve   # preview on http://localhost:4000/car/
npm run stickers -- --code 7KQ2M9XH4D                     # print files into _stickers/
npm test                                                  # needs Chrome + poppler-utils
```

Previous versions are preserved: **v1.0.0** server platform on branch `archive/v1-platform` (tag `v1.0.0`), and **v2.0.0** vehicle-page static site (tag `v2.0.0`). See [docs/MIGRATION_FROM_V1.md](docs/MIGRATION_FROM_V1.md).
